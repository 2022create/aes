#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>

double cha[16][256]; //u-average
double chadeviation[16][256]; //udev[j][b] / sqrt(tnum[j][b])
double cha2[16][256]; //u-average
double chadeviation2[16][256]; //udev[j][b] / sqrt(tnum[j][b])
double c[256];
double v[256];
int cpos[256];
unsigned char readykey[17] = {0x02,0x76,0x15,0x48,0x20,0x40,0xE3,0x27,0x22,0xD8,0x48,0xAD,0x23,0xD8,0x48,0x2D,0};
int cposcmp(const void *v1,const void *v2)
{
	int *i1 = (int *) v1;
	int *i2 = (int *) v2;
	if (c[255 & *i1] < c[255 & *i2]) return 1;
	if (c[255 & *i1] > c[255 & *i2]) return -1;
	return 0;
}
void processdata(char *addr)
{
	int b;
	int i;
	int j;
	int numok;
	double z;
	int key[16];
	FILE *fpWrite=fopen(addr,"w");
	for (b = 0;b < 16;++b) {
		for (i = 0;i < 256;++i) {
			c[i] = v[i] = 0;
			cpos[i] = i;
			for (j = 0;j < 256;++j) {
				c[i] += cha[b][j] * cha2[b][i ^ j];
				z = chadeviation[b][j] * cha2[b][i ^ j];
				v[i] += z * z;
				z = cha[b][j] * chadeviation2[b][i ^ j];
				v[i] += z * z;
			}
		}
		qsort(cpos,256,sizeof(int),cposcmp);
		numok = 0;
		for (i = 0;i < 256;++i)
			if (c[cpos[0]] - c[cpos[i]] < 10 * sqrt(v[cpos[i]]))
				++numok;
		fprintf(fpWrite,"%3d %2d",numok,b);
		int first=1;
		for (i = 0;i < 256;++i)
			if (c[cpos[0]] - c[cpos[i]] < 10 * sqrt(v[cpos[i]])){
				if(first==1){
					first=0;
					key[b]=cpos[i]^readykey[b];
				}
				fprintf(fpWrite," %02x",cpos[i]^readykey[b]);
			}
		fprintf(fpWrite,"\n");
	}
        printf("分析完成！：\n");
        printf("破解得到密钥结果为：\n");
	for(int i=0;i<16;i++){
		fprintf(fpWrite,"%02x ",key[i]);
               
                printf("%d ",key[i]);
	}
	fclose(fpWrite);
}
int  main (int argc,char *argv[])
{
        printf("数据分析开始：\n");
	FILE *fpRead=fopen(argv[1],"r");
	for(int i=0;i<16;i++){
		if(fpRead==NULL)
		{
			return 0;
		}
		for(int j=0;j<256;j++)
			fscanf(fpRead,"%lf ",&cha[i][j]);
		for(int j=0;j<256;j++)
			fscanf(fpRead,"%lf ",&chadeviation[i][j]);
	}
	fclose(fpRead);
	fpRead=fopen(argv[2],"r");
	for(int i=0;i<16;i++){
		if(fpRead==NULL)
		{
			return 0;
		}
		for(int j=0;j<256;j++)
			fscanf(fpRead,"%lf ",&cha2[i][j]);
		for(int j=0;j<256;j++)
			fscanf(fpRead,"%lf ",&chadeviation2[i][j]);
	}
	fclose(fpRead);
	
	processdata(argv[3]);
	/*
	for(int i=0;i<256;i++)
		printf("%f\n",cha[0][i]);
	printf("\n\n\n");
	for(int i=0;i<256;i++)
		printf("%f\n",cha2[0][i]);
	*/

	return 0;
}
